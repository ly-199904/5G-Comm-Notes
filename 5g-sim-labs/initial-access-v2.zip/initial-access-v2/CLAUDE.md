# 5G NR 初始接入全流程交互仿真 · 项目 Instructions

## 项目目标
用一套浏览器可直接运行的交互仿真，把 5G NR 初始接入（UE 上电 → 驻网）的完整流程
"演"出来：每个关键步骤都有可操作的动画、真实数值、协议出处。
技术栈：纯静态 HTML/JS/CSS（无构建工具），SVG 动画，预计算数据嵌入。
受众：通信工程专业学生 / 入行工程师。

## 规划中的 Stage 列表（5G 地面场景 · 9 Stage）

| Stage | 主题 | 核心教学点 |
|-------|------|-----------|
| 0 | UE 开机 | Tc 时钟基准、先验字典 |
| 1 | gNB SSB 广播 | Numerology / SSB Burst / GSCN / 时频网格 / MIB Polar 编码（TX 侧）|
| 2 | PSS 检测 | m-序列 / 零填充过采样 / 盲相关捞针 |
| 3 | SSS 检测 | 双 m-序列相乘 / N_ID¹ 解出 / PCI 合成 |
| 4 | PBCH 译码 & MIB | DMRS 信道估计+插值 / 两层解扰(夹心+自举) / Polar SCL+路径度量 / MIB 解析+SFN 拼接 / FR1-FR2 比特复用 |
| 5 | CORESET#0 盲检 | pdcch-ConfigSIB1 查表 / 时频反推 / PDCCH 盲检 / DCI 1_0 |
| 6 | SIB1 解析 | PDSCH 调度 / ASN.1 解码 / RACH 配置 + 小区驻留判决 |
| 7 | PRACH 随机接入 | Preamble / RA-RNTI / Msg1~2 / RAR + TA |
| 8 | RRC 建立 | SRB0 / Msg3~4 / 竞争解决 / 安全激活 |

终点说明：严格意义的「驻网（camping）」在 Stage 6 读完 SIB1 即完成；
Stage 7/8 属「接入」（→ RRC_CONNECTED）。完整故事讲到 RRC 建立。
PDU 会话（NAS 层）已越过 L1/L2 接入边界，规划为后续独立项目。
NTN（星地融合）场景亦为后续独立项目。

## 文件架构

```
initial-access-v2/
├── CLAUDE.md              ← 本文件（Claude 每次对话开始前必读）
├── design-system.css      ← 全局样式（唯一入口，勿在 HTML 内写全局样式）
├── engine.js              ← 状态机核心（勿改 API）
├── stage-data.js          ← NR_CTX + 所有 Stage 数据字典
├── index.html             ← Hub 导航（侧边栏 + iframe）
├── stage-0-boot.html      ← ✅ 完整
├── stage-1-gnb-ssb.html   ← ✅ 完整
├── stage-2-pss.html       ← ✅ 完整（S2.0~S2.3，含频偏估计理论卡）
├── stage-3-sss.html       ← ✅ 完整（S3.0~S3.3）
├── stage-4-pbch.html      ← ✅ 完整（S4.0~S4.4，5 子步）
├── stage-5-coreset.html   ← ✅ 完整（S5.0~S5.4，5 子步）
├── stage-6-sib1.html      ← ✅ 完整（S6.0~S6.4，5 子步）
├── stage-7-prach.html     ← ✅ 完整（S7.0~S7.4，5 子步）
└── stage-8-rrc.html      ← ✅ 完整（S8.0~S8.4，5 子步）

终点说明：严格意义的「驻网（camping）」在 Stage 6 读完 SIB1 即完成；
Stage 7/8 属「接入」（→ RRC_CONNECTED）。完整故事讲到 RRC 建立。
✅ 至此 L1/L2/RRC 空口接入（AS 层）主线全部收官（Stage 0~8）。
PDU 会话（NAS 层）已越过 L1/L2 接入边界，规划为后续独立项目（见 2.0）。
NTN（星地融合）场景亦为后续独立项目。
```

## 架构契约（每次开新 Stage 前必须对齐，违反必出 bug）

### 数据结构
```js
// ✅ 正确：必须用 { subSteps:[...] } 包裹
var S3 = { subSteps: [ discuss(...), sim(...), sim(...) ] };

// ❌ 错误：裸数组，subSteps=undefined，步骤切换全失效
var S3 = [ discuss(...), sim(...) ];
```

### Engine Hooks（每个 Stage HTML 必须实现）
```js
Engine.renderVizSVG  = function(subIdx){ ... };  // 返回 HTML 字符串注入 #vizContainer
Engine.onAfterRender = function(subIdx){ ... };  // DOM 就绪后启动动画
Engine.onStageExit   = function(){ ... };         // 清理所有定时器
Engine.boot({ stageIdx: N });                    // 最后一行
```

### SVG 规范（违反会导致布局错乱）
```html
<!-- ✅ 正确 -->
<svg viewBox="0 0 720 452" width="100%" height="100%" style="display:block;">

<!-- ❌ 错误 -->
<svg ... style="max-height:440px">   <!-- 不同子步骤高度不一致 -->
```
- 所有 `<text>` 加 `dominant-baseline="central"`
- 禁止在 `<text>` 内用 `&nbsp;`（改用 `&#160;`）或 HTML 标签（`<b>/<sub>` 不生效）
- 上下标写实体字符：N_ID² → `N_ID&#178;`，N_ID¹ → `N_ID&#185;`

### 动画性能规则
- **静态 DOM，只改属性**：动画只改 `fill/stroke/transform/opacity/textContent`，不每帧重建 SVG
- **例外**：数据量 < 500 节点的屏可以整图重绘（如 freq-coord、S2.2）
- 定时器必须经 `Engine.addTimer(tid)` 注册，`onStageExit` 负责清理
- 预计算数据嵌入 JS 字面量，动画不重算

## 颜色系统

参照标准：Stage 0 和 Stage 1 的配色是本项目的黄金标准。
Stage 2（PSS）因为全屏只有琥珀+灰双色被认为过于单调，新 Stage 必须避免重蹈。

### 各 Stage 主色
| Stage | 主色 | 浅色背景版 | 用途 |
|-------|------|-----------|------|
| 0 | #1d4ed8 深蓝 | #f0f6ff | 开机/时钟（实际用色，非靛蓝） |
| 1 | #0891b2 青色 | #cffafe | SSB 广播 |
| 2 | #d97706 琥珀 | #fff7ed | PSS 检测 |
| 3 | #7c3aed 紫色 | #ede9fe | SSS 检测 |
| 4 | #2563eb 蓝 | #eff6ff | PBCH 译码（扰码层用紫 #7c3aed 点睛，绿留作答案色） |
| 5 | #dc2626 红色 | #fee2e2 | RACH 接入 |
| 6 | #0284c7 蓝色 | #e0f2fe | RRC 建立 |

### SVG 配色执行规范
每屏必须覆盖的 5 个角色：

| 角色 | 含义 | 取色指引 |
|------|------|---------|
| 主角色 | 本屏核心信号/序列 | 当前 Stage 主色（饱和） |
| 答案色 | 判决成功/已解出/正确路 | #059669 绿，或主色加粗加亮 |
| 对照色 | 错误候选/未知/次要路 | #94a3b8 灰（柔和，不抢戏） |
| 高光色 | 锁定/判决/公式关键词的瞬间 | #dc2626 红（全屏最稀缺） |
| 底层色 | 背景卡片/基线/辅助线 | 主色浅色版渐变，不要纯白 |

三条执行红线：
- ❌ 主色 + 灰，缺第三色相 → 必须加入答案色或对照色
- ❌ 背景全部同一个浅灰 → 至少一个局部卡片用渐变或深色翻转
- ❌ 红色泛滥（超过 1 个用途）→ 红色只给"锁定高光"那一刻

## NR_CTX 全局上下文（跨 Stage 数据总线）

| 字段 | 写入 Stage | 含义 |
|------|-----------|------|
| `tc_ns` | S0 | Tc 时钟粒度（ns） |
| `gscn` / `arfcn` | S1 | 同步栅格 / NR-ARFCN |
| `ssb_case` / `scs_khz` | S1 | SSB Case / 子载波间隔 |
| `nid2` | S2.3 | N_ID²（PSS 盲检出） |
| `nid1` | S3 | N_ID¹（SSS 解出） |
| `pci` | S3 | PCI = 3·N_ID¹ + N_ID² |
| `sfn_offset` / `hrf` | S4 | 系统帧号 / 半帧 |
| `kssb` / `mib` | S1/S4 | k_SSB / MIB 字节 |

写入用 `Engine.ctxSet(key, val)`（自动刷新顶部标签）。
**原则：只有真正检测/解码出来之后才写入**，不能"还没检测就先知"。

## 历史踩坑（禁止重犯）

1. `S3 = [...]` 不加 `subSteps` 包装 → 步骤切换全失效
2. SVG `<text>` 内 `&nbsp;` → 渲染为字面量，改用 `&#160;`
3. `max-height` 写死 SVG → 不同子步骤高度不一致
4. "补零让 PSS 变平滑"→ 物理错误，正确说法是"过采样使连续波形可见"
5. GSCN 默认值曾为 8778（FR1 外）→ 已改为 7881（n78 中心）
6. 没有基线文件（engine.js / 参考 Stage HTML）就猜 API 签名 → 必出返工
7. 动画数据没有预计算直接在 setInterval 里每帧重算 → 卡顿
8. 判决写总线过早（还没检测就 ctxSet）→ 破坏"零先验"叙事逻辑
9. SVG <text> 内写裸 << / < / > / & → XML 非法 token（cairosvg 直接报错）；<< 必须写 `&lt;&lt;`。
10. Stage HTML 末尾 hook 赋值在 Engine.boot() 之前，而 boot 会把 onStageExit 重置为 null——这是 Stage 3 黄金参考的既定行为，单文件/iframe 生命周期内 onStageExit 不会被子步切换调用，清理靠 iframe 销毁，属正常，勿"修复"。
11. SVG 比特带/卡片做成数据驱动数组（如 DCI_FIELDS）后，加字段只改数组、渲染循环用 totBits 自动均分——这是正确做法，勿在渲染里写死字段数；但要同步检查依赖该数组长度的下游坐标（卡片行数→sumY、计数器 x/N）。
12. 顶部并排短标签若文字过长会重叠（S5.1 曾把 controlResourceSetZero 全称放钥匙下方撞车）→ 并排标签用短名（cset0/ss0），全称放到下方表头或理论卡。
13. 频域 offset 类「相邻两块落差」标注，勿画在网格边界外（会和轴标签 RB0 打架且箭头太短看不清）→ 画在两块之间的空档，用双向箭头 + 白底标签框。
14. SVG <text> 内裸 `&`（如"解调 & LDPC"）→ XML 非法 token，cairosvg 直接 ParseError；必须写 `&amp;`（与踩坑#9 的 << 同源问题）。注意只影响 SVG <text>，HTML 卡片文案里浏览器较宽容。
15. theoryCard 文案要插入新小节导致后续编号顺移（③→④→⑤）时，用 str_replace 改一处易漏改下游；插入后务必 grep 一遍 `<h3>` 编号连续性，逐个补改，别只改插入点。
16. 数轴类"负数减法"（如 Srxlev=−75−(−110)=+35）初学者视觉易短路 → 用"死亡线/你的信号"直觉命名两端点 + 醒目双向箭头 + 缓冲垫胶囊标签 + 减法展开式并列，比单写"余量+35dB"教学效果好得多。
17. SVG <text> 内裸 `&`（如方向色例「方向色例 & 接入类型」）→ XML 非法 token，cairosvg ParseError；必须写 `&amp;`（与踩坑 #14 同源，但 #14 是 HTML 卡片宽容、本条在 SVG <text> 内严格）。
18. 窗口/时序类「起跑线」表述别把「协议定时参考起点（≥1 符号）」和「设备真实处理预算」混为一谈（PRACH 的 ra-ResponseWindow 起算点 ≠ gNB 处理时延）。把两者说成一回事虽更顺口，但对工程师受众是物理失真——分开讲，并用「动画里命中落在中段而非第 0 时机」做直觉锚点。
19. 比特带各字段位长之和必须 = 标题宣称的 SDU 总长，否则自相矛盾（S8.1 曾画 39+4+1=44 却标 48-bit CCCH SDU）。消失的位往往是 UPER 的 CHOICE 路由头/扩展位/长度前缀这类「结构开销」——凑数前先做逐位预算（ceil(log2(N)) 算每个 CHOICE 的选择位），别只数语义字段。修正后顺手把 loop 边界从写死的 i<N 改成 i<fields.length（同踩坑 #11）。
20. 安全激活的时序别为了「故事顺」而失真：真实 3GPP 序是 Msg4→CONNECTED→Msg5(含NAS)→NAS鉴权→SMC→SMP，即 AS 安全(SMC) 在 RRC_CONNECTED 之后、K_gNB 源自 NAS 鉴权（本项目越界）。把它画成建连的同步动作虽顺口，但对工程师受众是物理失真——如实标注「越界」「在 CONNECTED 之后」。

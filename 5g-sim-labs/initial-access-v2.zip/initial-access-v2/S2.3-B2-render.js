
/* ─── Sub 3: 时域盲相关检测 / 海面捞针 ─────────────────── */
var _csSnr='mid';        // 'high'|'mid'|'low'
var _csScan=0;           // 扫描进度 0..N_c
var _csTid=null;
var _csLocked=false;
var CS_RX0=40, CS_RX1=680;
var CS_NRX=210, CS_NC=294;
var CS_COL=['#94a3b8','#d97706','#64748b'];   // N_ID2=0/1/2

function _csXc(i){ return CS_RX0+(i/(CS_NC-1))*(CS_RX1-CS_RX0); }
function _csXr(i){ return CS_RX0+(i/(CS_NRX-1))*(CS_RX1-CS_RX0); }

function _csRxPath(){
  var rx=CS_DATA[_csSnr].rx, mx=0;
  for(var i=0;i<rx.length;i++) mx=Math.max(mx,Math.abs(rx[i]));
  var p='';
  for(var j=0;j<rx.length;j++){ var y=95 - rx[j]/mx*32; p+=(j===0?'M':'L')+_csXr(j).toFixed(1)+' '+y.toFixed(1); }
  return p;
}
function _csCorrPaths(upto){
  var D=CS_DATA[_csSnr], cmax=0, k, i;
  for(k=0;k<3;k++){ var c=D['c'+k]; for(i=0;i<c.length;i++) cmax=Math.max(cmax,Math.abs(c[i])); }
  var CYb=400, CY0=210;
  var cy=function(v){ return CYb - v/cmax*(CYb-CY0); };
  var out=[];
  for(k=0;k<3;k++){
    var arr=D['c'+k], p='', lim=Math.min(upto,arr.length);
    for(i=0;i<lim;i++) p+=(i===0?'M':'L')+_csXc(i).toFixed(1)+' '+cy(arr[i]).toFixed(1);
    out.push(p);
  }
  return {paths:out, cy:cy, cmax:cmax};
}

function renderCorrSearch(){
  var D=CS_DATA[_csSnr];
  var rxp=_csRxPath();
  var cc=_csCorrPaths(_csScan);
  var scanX=_csXc(Math.min(_csScan,CS_NC-1));
  var det=D.det, detlag=D.detlag;
  var lockSVG='';
  if(_csLocked){
    var px=_csXc(detlag), py=cc.cy(D['c'+det][detlag]);
    lockSVG='<line x1="'+px.toFixed(1)+'" y1="'+py.toFixed(1)+'" x2="'+px.toFixed(1)+'" y2="400" stroke="#dc2626" stroke-width="1" stroke-dasharray="3 3"/>'+
      '<circle cx="'+px.toFixed(1)+'" cy="'+py.toFixed(1)+'" r="5.5" fill="none" stroke="#dc2626" stroke-width="2"/>'+
      '<text x="'+px.toFixed(1)+'" y="'+(py-13).toFixed(1)+'" text-anchor="middle" dominant-baseline="central" font-family="SF Mono,Consolas,monospace" font-size="10.5" font-weight="700" fill="#dc2626">N_ID²='+det+' 锁定 @lag'+detlag+'</text>';
  }
  var svg='<svg viewBox="0 0 720 452" width="100%" height="100%" style="display:block;" xmlns="http://www.w3.org/2000/svg">'+
    '<rect x="14" y="14" width="692" height="424" rx="14" fill="#f8fafc" stroke="#d4dce8" stroke-width="1.5"/>'+
    '<text x="360" y="32" text-anchor="middle" dominant-baseline="central" font-family="SF Mono,Consolas,monospace" font-size="12" font-weight="700" fill="#b45309">时域盲相关检测：三路模板滑过含噪接收信号，谁先冒尖谁就是 N_ID²</text>'+
    '<text x="40" y="52" dominant-baseline="central" font-family="SF Mono,Consolas,monospace" font-size="10" font-weight="700" fill="#1e293b">① 接收信号 r[n]（PSS 埋在噪声里，肉眼看不出）</text>'+
    '<line x1="'+CS_RX0+'" y1="95" x2="'+CS_RX1+'" y2="95" stroke="#e2e8f0" stroke-width="1"/>'+
    '<path d="'+rxp+'" fill="none" stroke="#64748b" stroke-width="0.8" opacity="0.8"/>'+
    '<text x="40" y="150" dominant-baseline="central" font-family="SF Mono,Consolas,monospace" font-size="10" font-weight="700" fill="#1e293b">② 三路相关器输出（滑动互相关，取最大峰判决）</text>'+
    '<line x1="'+CS_RX0+'" y1="400" x2="'+CS_RX1+'" y2="400" stroke="#cbd5e1" stroke-width="1"/>'+
    '<path d="'+cc.paths[0]+'" fill="none" stroke="'+CS_COL[0]+'" stroke-width="1" opacity="0.65"/>'+
    '<path d="'+cc.paths[2]+'" fill="none" stroke="'+CS_COL[2]+'" stroke-width="1" opacity="0.65"/>'+
    '<path d="'+cc.paths[1]+'" fill="none" stroke="'+CS_COL[1]+'" stroke-width="1.8"/>'+
    (_csScan<CS_NC?'<line x1="'+scanX.toFixed(1)+'" y1="150" x2="'+scanX.toFixed(1)+'" y2="400" stroke="#dc2626" stroke-width="1" opacity="0.5"/>':'')+
    lockSVG+
    '<text x="50" y="418" dominant-baseline="central" font-family="SF Mono,Consolas,monospace" font-size="9" fill="#d97706">— N_ID²=1（正确）</text>'+
    '<text x="240" y="418" dominant-baseline="central" font-family="SF Mono,Consolas,monospace" font-size="9" fill="#94a3b8">— N_ID²=0</text>'+
    '<text x="380" y="418" dominant-baseline="central" font-family="SF Mono,Consolas,monospace" font-size="9" fill="#64748b">— N_ID²=2</text>'+
    '<text x="680" y="418" text-anchor="end" dominant-baseline="central" font-family="SF Mono,Consolas,monospace" font-size="9" fill="#475569">SNR='+D.snr+'dB</text>'+
    '</svg>';
  var sbtn=function(s,lbl){ return '<button class="case-btn'+(_csSnr===s?' on':'')+'" onclick="csSnr(\''+s+'\')">'+lbl+'</button>'; };
  var ctrl='<div class="ctrl-bar">'+sbtn('high','SNR 高')+sbtn('mid','SNR 中')+sbtn('low','SNR 低')+
    '<span style="width:1px;height:18px;background:var(--border);"></span>'+
    '<button class="case-btn" onclick="csScan()">▶ 开始扫描</button>'+
    '<button class="case-btn" onclick="csReset()">↺ 复位</button></div>';
  return '<div style="width:100%;height:100%;display:flex;flex-direction:column;align-items:center;gap:8px;padding-top:18px;">'+
    ctrl+'<div style="flex:1;width:100%;min-height:0;">'+svg+'</div></div>';
}

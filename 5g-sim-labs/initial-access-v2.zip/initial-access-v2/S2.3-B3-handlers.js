/* ─── 事件 + 动画 hooks ─── */
function _csVC(){ return document.getElementById('vizContainer'); }
function _csRerender(){ var vc=_csVC(); if(vc) vc.innerHTML=renderCorrSearch(); }

function csSnr(s){
  if(_csTid){ clearInterval(_csTid); _csTid=null; }
  _csSnr=s; _csScan=0; _csLocked=false; _csRerender();
}
function csScan(){
  if(_csTid){ clearInterval(_csTid); _csTid=null; }
  _csScan=0; _csLocked=false; _csRerender();
  var det=CS_DATA[_csSnr].det, detlag=CS_DATA[_csSnr].detlag;
  _csTid=setInterval(function(){
    _csScan+=3;
    if(_csScan>=CS_NC){
      _csScan=CS_NC; _csLocked=true;
      clearInterval(_csTid); _csTid=null;
      _csRerender();
      Engine.ctxSet('nid2', det);                       // 判决写总线
      Engine.LogEngine.inject('[PHY] ✓ 找到符号边界！锁定 N_ID²='+det+' @lag'+detlag+'。');
      Engine.LogEngine.inject('[PHY] 写入 NR_CTX.nid2='+det+'，PCI = 3·N_ID¹ + '+det+'（N_ID¹ 待 SSS）。');
    } else {
      _csRerender();
    }
  },24);
  Engine.addTimer(_csTid);
}
function csReset(){
  if(_csTid){ clearInterval(_csTid); _csTid=null; }
  _csScan=0; _csLocked=false; _csRerender();
}

# CLAUDE.md — 5G-Comm-Notes

## 项目概述

个人 5G NR / NTN（星地融合通信）学习笔记库，目标是从"协议+代码+仿真"三个维度建立通信系统工程能力。

- **仓库**: github.com/ly-199904/5G-Comm-Notes
- **在线站点**: 通过 VitePress 构建，部署在 GitHub Pages（base: `/5G-Comm-Notes/`）
- **规范基准**: 3GPP Rel-15/16/17
- **语言**: 中文（zh-CN）

## 项目结构

```
5G-Comm-Notes/
├── docs/                          # VitePress 文档站点
│   ├── .vitepress/
│   │   ├── config.mts             # 站点配置（导航、侧边栏、KaTeX、Mermaid）
│   │   ├── components/            # Vue 交互组件（*.vue，全局注册）
│   │   └── theme/                 # 自定义主题
│   ├── index.md                   # 首页（hero layout）
│   ├── phase1/                    # 基石层：Numerology / 资源网格 / 信道映射 / OFDM
│   ├── phase2/                    # 骨架层：RACH / PDCCH+DCI / HARQ / MIMO / CSI / Beam Mgmt
│   ├── phase3/                    # NTN 前沿：架构 / TA 大时延 / Doppler / Rel-17 增强
│   └── code/                      # 仿真代码说明文档（每篇对应一个 .py）
├── simulation/
│   ├── phase1/                    # Phase 1 仿真脚本 + 输出图片
│   ├── phase2/                    # Phase 2 仿真脚本 + 输出图片
│   └── requirements.txt
└── package.json                   # VitePress + Mermaid 插件
```

## 三阶段学习路线

| Phase | 主题 | 状态 |
|-------|------|------|
| Phase 1 基石层 | Numerology、Resource Grid、Channel Mapping、OFDM | ✅ 完成 |
| Phase 2 骨架层 | RACH ✅、PDCCH & DCI ✅、HARQ ⬜、MIMO ⬜、CSI ⬜、Beam Mgmt ⬜ | 进行中 |
| Phase 3 NTN 前沿 | NTN 架构、Timing Advance、Doppler 补偿、Rel-17 增强 | ⬜ 待开始 |

## 每节课的输出规范（7 项）

每新增一个知识点，必须产出以下三个文件：

### 1. 理论笔记（`docs/phase{n}/{topic}.md`）
- **版本定锚**: 表格标注 Rel-15/16/17 归属 + 3GPP 规范号
- **知识定位**: ASCII 树状图展示在整体知识体系中的位置
- **深度推导**: 原理 → 公式（KaTeX `$$` 块）→ 关键 IE 字段（RRC 树形结构）
- **NTN 深度分析**: Phase 2/3 专题必须包含 NTN 视角的定量分析
- **故障排查速查表**: 表格形式（现象 / 首先检查 / 最可能根因）
- **版本演进速览**: 表格标注各 Release 的支持情况
- **自测题**: 3 道面试级别工程题，使用 `:::details` 折叠答案
- **参考资料**: 规范号 + ShareTechnote + 经典教材

### 2. 仿真代码（`simulation/phase{n}/{topic}_sim.py`）
- 文件头 docstring 标注 3GPP 参考章节
- 使用 NumPy / Matplotlib，必要时 SciPy
- 暗色主题（`DARK_BG='#0d1117'` 等），统一 `ax_style()` 辅助函数
- 输出图片保存到脚本同目录（`OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))`）
- 模块化：数据生成 → 核心算法 → 可视化，每块用分隔线注释标注
- 含 `if __name__ == '__main__':` 入口

### 3. 代码说明文档（`docs/code/{topic}-sim.md`）
- 对应理论笔记和脚本位置链接
- 一分钟速览（ASCII 框图）
- 环境配置 + 运行命令
- 数学-代码对照（至少 3 组：协议公式 → 代码片段 → 验证方法）
- 仿真参数说明表（参数 / 默认值 / 物理含义 / 修改建议）
- 预期输出图表解读（每张图的布局、颜色含义、关键观察、异常诊断）
- NTN Context（`:::info` 块，含 Rel-17 背景 + 实验建议）
- 3GPP 协议溯源表

### 可视化组件（可选，按需）
- Vue 3 SFC，放在 `docs/.vitepress/components/`
- 文件名 PascalCase，在 `.md` 中直接使用（VitePress 自动全局注册）
- 暗色主题一致，带交互式控件

## 对话协议

用户（我）发送格式：
```
🔗 链接：[ShareTechnote URL 或留空]
📌 目标：[知识点名称]
⚙️ 模式：[速读摘要 / 深度推导 / 代码实战 / 故障排查]
```

你的回复应包含对应模式所需的理论笔记、仿真代码和代码说明文档。

## 技术约定

- **KaTeX**: 行内 `$...$`，块级 `$$...$$`，VitePress 已配置 `markdown.math: true`
- **Mermaid**: 通过 `vitepress-plugin-mermaid` 支持，在 `.md` 中用 ` ```mermaid` 代码块
- **Vue 组件**: 放在 `.vitepress/components/` 下即可全局使用，无需手动注册
- **部署命令**: `npm run docs:build` → 推送到 `gh-pages` 分支
- **本地开发**: `npm run docs:dev`

## 当前状态（2026-05-23）

- Phase 1 全部完成（4 篇笔记 + 4 个仿真 + 4 篇说明文档 + 5 个 Vue 组件）
- Phase 2 已完成：RACH、PDCCH & DCI、HARQ
- Phase 2 待完成：MIMO & Beamforming、CSI 框架、Beam Management
- Phase 3 全部待开始

## 编码行为准则

### 1. 先想清楚再动手
- 遇到模糊需求时，先列出假设和多种理解方式，不要默默选一种
- 如果有更简单的实现路径，主动提出；用户说"做 X"但你觉得 Y 更好，直接说
- 不确定时停下来，把困惑点说清楚，而不是猜测一个方案硬上

### 2. 只写必要的代码
- 不写需求之外的功能，不加"以备将来"的灵活性和配置项
- 不为单次使用的代码建抽象层，三行重复不算重复
- 仿真代码允许必要的教学性冗长（多图、多场景比对），但同一计算逻辑不重复三遍

### 3. 精准改动，不动无关代码
- 只改任务范围内的文件和行，不顺手"优化"相邻代码、注释、格式
- 不重构没坏的东西，不替用户决定什么该清理
- 你的改动产生的孤立 import/变量，清理掉；任务范围外的遗留问题，口头提一句就好

### 4. 以可验证目标驱动
- 每步改动定义检查点：改笔记 → `npm run docs:dev` 确认 KaTeX/Mermaid 渲染正常；改仿真 → `python xxx_sim.py` 确认图片生成无报错
- 多步任务先列清单，逐条验证后勾掉，不要最后一次性检查

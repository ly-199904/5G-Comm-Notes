# CSI 框架（RI / PMI / CQI）

> **3GPP 版本定锚**
>
> | 内容 | 版本 | 规范 |
> |---|---|---|
> | CSI 基础框架（RI/PMI/CQI/CRI/LI） | **Rel-15** | 38.214 §5.2 |
> | CSI-RS 资源配置（NZP / ZP） | **Rel-15** | 38.211 §7.4.1.5 |
> | Type II 高精度码本 | **Rel-16** | 38.214 §5.2.2.2.5 |
> | CSI 压缩与 AI/ML 辅助（NC-JT） | **Rel-17** | 38.214 §5.2.6 |

---

## 📡 知识定位

```
Phase 2 骨架层
│
├── ✅ RACH 随机接入
├── ✅ PDCCH & DCI 调度机制
├── ✅ HARQ 混合自动重传
├── ⬜ MIMO & Beamforming
│
├── ▶ CSI 框架               ← 我们在这里
│
└── ⬜ Beam Management
```

---

🚧 **内容施工中** — 本节将覆盖：CSI-RS 资源配置 / RI/PMI/CQI 反馈机制 / 周期/非周期/半持续 CSI 上报 / Type I vs Type II 码本 / CSI 在 AMC 和 MIMO 预编码中的驱动角色。

---
